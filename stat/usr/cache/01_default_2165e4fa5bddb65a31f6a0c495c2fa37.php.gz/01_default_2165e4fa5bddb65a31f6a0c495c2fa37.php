<?php
//This is a temporary file which has been automatically created by CrazyStat. You can delete it. Then CrazyStat will be slower the next time (and recreate the file).

$pos=196;
$logdatei_name='../usr/logs/stat0.log';
$hits_user_tag=array (
  '16.10.2013' => 1,
);
$ips=array (
  '::1..230.30*' => 767730,
);
$ips_dateien=array (
  '::1..230.30*#/stat/example.php?XDEBUG_SESSION_START=19718' => 767730,
);
$ips_online=array (
);
$log_file_number=0;
$last_seen=array (
  '::1..230.30*' => 1381914708,
);
$first_seen=array (
  1381914708 => 
  array (
    0 => '::1..230.30*',
  ),
);
$save_timestamp=1381914725;
$usr_on_stamp=array (
  '::1..230.30*' => 1381914708,
);
$_SESSION["module_hit_data"]=array (
  'gesamt' => 1,
  'gesamt_ip' => 1,
  'diesen_monat' => 1,
  'letzten_monat' => 0,
  'user_online' => 1,
  'max' => 1,
  'durchschnitt' => 1,
  'visit_time_total' => 0,
  'max_tag' => '16.10.2013',
  'proUser' => 1,
  'visit_time_avg' => 0,
);
$_SESSION["module_hit_data_timestamps"]=array (
);
$_SESSION["module_weekday_data"]=array (
  1 => 0,
  2 => 0,
  3 => 1,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
);
$_SESSION["module_weekday_data_timestamps"]=array (
  3 => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_month_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 1,
  11 => 0,
  12 => 0,
);
$_SESSION["module_month_data_timestamps"]=array (
  10 => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_day_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 1,
  17 => 0,
  18 => 0,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 0,
  23 => 0,
  24 => 0,
  25 => 0,
  26 => 0,
  27 => 0,
  28 => 0,
  29 => 0,
  30 => 0,
);
$_SESSION["module_day_data_timestamps"]=array (
  16 => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_hour_data"]=array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 1,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 0,
  17 => 0,
  18 => 0,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 0,
  23 => 0,
);
$_SESSION["module_hour_data_timestamps"]=array (
  11 => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_browser_data"]=array (
  'Google Chrome' => 1,
);
$_SESSION["module_browser_data_timestamps"]=array (
  'Google Chrome' => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_file_data"]=array (
  '/stat/example.php?XDEBUG_SESSION_START=19718' => 1,
);
$_SESSION["module_file_data_timestamps"]=array (
  '/stat/example.php?XDEBUG_SESSION_START=19718' => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_resolution_data"]=array (
  '1280 x 1024' => 1,
);
$_SESSION["module_resolution_data_timestamps"]=array (
  '1280 x 1024' => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_colordepth_data"]=array (
  24 => 1,
);
$_SESSION["module_colordepth_data_timestamps"]=array (
  24 => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_system_data"]=array (
  'Win' => 1,
);
$_SESSION["module_system_data_timestamps"]=array (
  'Win' => 
  array (
    0 => 1381914708,
  ),
);
$_SESSION["module_referer_data"]=array (
);
$_SESSION["module_referer_data_timestamps"]=array (
);
$_SESSION["module_keyword_data"]=array (
);
$_SESSION["module_keyword_data_timestamps"]=array (
);
?>