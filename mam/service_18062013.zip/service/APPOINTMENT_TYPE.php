<?php
/**
 * Created by Thammarak.
 * Date: 12/5/2556
 * Time: 9:43 น.
 */
class APPOINTMENT_TYPE
{
    /**วันหยุด*/
    const HOLIDAY = 0;
    /**ประชุม*/
    const MEETING = 1;
    /**สัมนา*/
    const SEMINAR = 2;
    /**ฟังบรรยาย*/
    const PRESENT = 3;
}
