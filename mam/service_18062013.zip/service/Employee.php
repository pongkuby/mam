<?php
include_once 'database.php';

/**
 * Created by Thammarak
 * Date: 8/5/2556
 * Time: 13:58 น.
 */
class Employee
{
    /**ID ของ Employee*/
    public $empId;
    /**ชื่อ*/
    public $firstName;
    /**นามสกุล*/
    public $lastName;
    /**Email*/
    public $email;
    /**โทรศัพท์*/
    public $phone;
    /**แผนก*/
    public $division;
	/**เบอร์เครื่องกลาง**/
	public $telcenter;
	/**เบอร์ภายใน**/
	public $ext_no;
	/**ระดับ**/
	public $sub_group;

	/**ระดับผู้บริหาร**/
	public $ee_group;


	




    /**ดึงข้อมูล Employee โดยใช้ ID*/
    public static function getEmployeeById($empId){
        $db = Database::getPDO();
        $query = $db->prepare("SELECT * FROM employee WHERE emp_id=:empid ;");
        $query->bindParam(":empid", $empId);
        $query->execute();
        $data = $query->fetch(PDO::FETCH_ASSOC);
        if (!$data) {
            return null;
        } else {
            return Employee::mapData($data);
        }
    }

    /**ค้นหา Employee */
    public static function getEmployeesByName($name)
    {
        $employees = new ArrayObject();
        $db = Database::getPDO();
        $query = $db->prepare("SELECT * FROM employee WHERE first_name like ? or last_name like ? or org_unit_text like ?;");
        $params = array("%$name%", "%$name%", "%$name%");
        $query->execute($params);
        while ($row = $query->fetch()) {
            $employee = Employee:: mapData($row);
            $employees->append($employee);
        }
        if ($employees->count() > 0) {
            return $employees->getArrayCopy();
        } else {
            return $employees;
        }
    }

    /**Return Owner ของ Appointment*/
    public static function getOwnerAppointment($appid)
    {
        $db = Database::getPDO();
        $query = $db->prepare("SELECT * FROM appointment_emp a
            INNER JOIN employee e ON a.emp_id = e.emp_id
            WHERE a.app_id = :appid;");
        $query->bindParam(":appid", $appid);
        $query->execute();
        $employees = new ArrayObject();
        while ($row = $query->fetch()) {
            $employee = Employee::mapData($row);
            $employees->append($employee);
        }
        if ($employees->count() > 0) {
            return $employees->getArrayCopy();
        } else {
            return false;
        }
    }

    /**Return Viewer ของ Appointment*/
    public static function getViewerAppointment($appid)
    {
        $db = Database::getPDO();
        $query = $db->prepare("SELECT * FROM appointment_show a
            INNER JOIN employee e ON a.emp_id = e.emp_id
            WHERE a.app_id = :appid;");
        $query->bindParam(":appid", $appid);
        $query->execute();
        $employees = new ArrayObject();
        while ($row = $query->fetch()) {
            $employee = Employee::mapData($row);
            $employees->append($employee);
        }
        return $employees->getArrayCopy();
    }

    /** Return Mock Data ของ Employee*/
    private static function getMockEmployee()
    {
        $employees = new ArrayObject();
        $employee = new Employee();
        $employee->empId = "00029025";
        $employee->firstName = "ผุสดี";
        $employee->lastName = "ขอมทอง";
        $employee->email = "kphusade@mwa.co.th";
        $employee->phone = "0813551445";
        $employee->division = "ฝพท.";
        $employees->append($employee);

        $employee = new Employee();
        $employee->empId = "00068381";
        $employee->firstName = "ขนิษฐา";
        $employee->lastName = "ผลเจริญ";
        $employee->email = "pkanitta@mwa.co.th";
        $employee->phone = "0894594914";
        $employee->division = "ฝพท.";
        $employees->append($employee);

        $employee = new Employee();
        $employee->empId = "00072451";
        $employee->firstName = "พิศวาท";
        $employee->lastName = "ภาพสุวรรณ";
        $employee->email = "ppit@mwa.co.th";
        $employee->phone = "0841459433";
        $employee->division = "ฝพท.";
        $employees->append($employee);

        $employee = new Employee();
        $employee->empId = "00071757";
        $employee->firstName = "เมธาวี";
        $employee->lastName = "สุชาติล้ำพงศ์";
        $employee->email = "smethawee@mwa.co.th";
        $employee->phone = "0816590949";
        $employee->division = "ฝพท.";
        $employees->append($employee);

        $employee = new Employee();
        $employee->empId = "00080845";
        $employee->firstName = "ชุติญา";
        $employee->lastName = "กิจขุนทด";
        $employee->email = "chutiya@mwa.co.th";
        $employee->phone = "1364";
        $employee->division = "ฝพท.";
        $employees->append($employee);
        return $employees->getArrayCopy();
    }

    /** Map Data จาก Table เป็น Object*/
    private static function mapData($row)
    {
        if (!$row) {
            return false;
        }
        $employee = new Employee();
        $employee->empId = $row["emp_id"];
        $employee->firstName = $row["first_name"];
        $employee->lastName = $row["last_name"];
        $employee->email = $row["email"];
        $employee->phone = $row["phone"];
        $employee->division = $row["org_unit_text"];


		//$employee->telcenter = $row["telcenter"];

		if($row["direct_no"]!=""&&$row["direct_no"]!="-"){
			$employee->telcenter = substr(str_replace(" ","",$row["direct_no"]),0,9);
		}else if($row["telcenter"]!=""&&$row["telcenter"]!="-"){
			$employee->telcenter = substr(str_replace(" ","",$row["telcenter"]),0,9);
			$employee->ext_no ="ต่อ".$row["ext_no"];
		}

		
		$employee->sub_group = $row["sub_group"];
		$employee->ee_group = $row["ee_group"];

		
		
		/*$employee->telcenter = $row["direct_no"];
		$employee->telcenter = $row["telcenter"];
		$employee->ext_no =$row["ext_no"];*/
		
        return $employee;
    }

}
