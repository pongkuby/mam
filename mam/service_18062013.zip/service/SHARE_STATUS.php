<?php
/**
 * Created by Thammarak.
 * Date: 10/5/2556
 * Time: 16:11 น.
 */
class SHARE_STATUS
{
    /*แสดงทั้งหมด*/
    const ALL = 1;
    /*แสดงเป็น Busy*/
    const BUSY = 2;
    /*ระบุ Employee*/
    const SPECIFY = 3;
}
