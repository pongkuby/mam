<?php
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();
include_once "database.php";
include_once "Employee.php";
include_once "SHARE_STATUS.php";
include_once "Appointment.php";
include_once "MamUtil.php";
include_once "Login.php";
$app = new \Slim\Slim();
$app->get(
    '/',
    function () {
        include('manual.php');
        exit;
    }
);

/*================= Employee =================*/
/**check login*/
$app->get(
    '/login/:empId&:pass', function ($empId, $pass) {
        /*echo $empId."<BR>";
        echo $pass."<BR>";*/
        $employee = Login::getLogin($empId, $pass);
        if (count($employee) > 0) {
            echo json_encode(array("success" => true, "login" => array($employee)));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** Search Employee โดยใช้ชื่อ*/
$app->get(
    '/getemployee/:empId', function ($empId) {
        $employee = Employee::getEmployeeById($empId);
        if (count($employee) > 0) {
            echo json_encode(array("success" => true, "employees" => array($employee)));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** Search Employee โดยใช้ชื่อ*/
$app->get(
    '/getemployees/:name', function ($name) {
        $employees = Employee::getEmployeesByName($name);
        if (count($employees) > 0) {
            echo json_encode(array("success" => true, "employees" => $employees));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);
/** Search Employee ทั้งหมด*/
$app->get(
    '/getallemployee/:name', function ($name) {
        $employees = Employee::getEmployeesByName('');
        if (count($employees) > 0) {
            echo json_encode(array("success" => true, "employees" => $employees));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/*================ ตารางนัดหมาย =================*/
/** ดึงตารางนัดหมายของ Employee*/
$app->get(
    '/getappointments/:empid/:year/:month', function ($empid, $year, $month) {
        $apps = Appointment::getEmployeeAppointment($empid, $year, $month);
        if (count($apps) > 0) {
            echo json_encode(array("success" => true, "appointments" => $apps));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** ดึงตารางนัดหมายของ Employee โดยใช้ปี*/
$app->get(
    '/getappointments/:empid/:year/', function ($empid, $year) {
        $apps = Appointment::getEmployeeAppointmentByYear($empid, $year);
        if (count($apps) > 0) {
            echo json_encode(array("success" => true, "appointments" => $apps));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** ดึงตารางนัดหมายโดยใช้ id*/
$app->get(
    '/getappointment/:appid', function ($appid) {
        $app = Appointment::getAppointment($appid);
        if ($app != null) {
            echo json_encode(array("success" => true, "appointment" => $app));

        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** ดึงตารางนัดหมายโดยใช้ Keyword*/
$app->get(
    '/getappointments/:empid/:keyword', function ($empid, $keyword) {
        $apps = Appointment::findEmployeeAppointment($empid, $keyword);
        if (count($apps) > 0) {
            echo json_encode(array("success" => true, "appointments" => $apps));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** view ตารางนัดหมายของ employee รายปี */
$app->get(
    '/viewappointments/:empid/:year/:month/:viewerid', function ($empid, $year, $month, $viewerid) {
        $apps = Appointment::viewEmployeeAppointments($empid, $year, $month, $viewerid);
        if (count($apps) > 0) {
            echo json_encode(array("success" => true, "appointments" => $apps));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** view ตารางนัดหมายของ employee รายปี */
$app->get(
    '/viewappointments/:empid/:year/:viewerid', function ($empid, $year, $viewerid) {
        $apps = Appointment::viewEmployeeAppointmentsByYear($empid, $year, $viewerid);
        if (count($apps) > 0) {
            echo json_encode(array("success" => true, "appointments" => $apps));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** ดึงข้อมูลวันหยุด*/
$app->get(
    '/getholidays/:year/:month', function ($year, $month) {
        $rows = Holiday::getHolidays($year, $month);
        if ($rows != null) {
            echo json_encode(array("success" => true, "holidays" => $rows));

        } else {
            echo json_encode(array("success" => false));
        }
    }
);

/** สร้างตารางนัดหมาย*/
$app->post('/postappointment', function () use ($app) {
    $request = $app->request();
    $values = $request->post();
    $appointment = new Appointment();
    $appointment = mapRequestToAppointment($appointment, $values);
    if ($appointment->insert()) {
        $app->response()->header('Content-Type', 'application/json;charset=utf-8');
        echo json_encode(array("success" => true, "appointment" => $appointment));
    } else {
        echo json_decode(array("success" => false, "appointment" => null));
    }
});

/** Update ตารางนัดหมาย*/
$app->put('/putappointment', function () use ($app) {
    $request = $app->request();
    $values = $request->post();
    $appointment = Appointment::getAppointment($values["appId"]);
    if ($appointment == null) {
        echo json_encode(array("success" => false,
            "message" => "app id not found."));
        return;
    }
    $appointment = mapRequestToAppointment($appointment, $values);
    if ($appointment->update()) {
        $app->response()->header('Content-Type', 'application/json;charset=utf-8');
        echo json_encode(array("success" => true, "appointment" => $appointment));
    } else {
        echo json_decode(array("success" => false, "appointment" => null));
    }
});

/** ลบตารางนัดหมาย*/
$app->delete(
    '/deleteappointment/:appid', function ($appid) {
        if (Appointment::deleteAppointment($appid)) {
            echo json_encode(array("success" => true));
        } else {
            echo json_encode(array("success" => false));
        }
    }
);

$app->run();

/** Map request to Appointment Object*/
function mapRequestToAppointment(Appointment $app, array $values)
{
    $app->appId = $values["appId"];
    $app->appType = $values["appType"];
    $app->event = $values['event'];
    $app->title = $values["title"];
    $app->place = $values["place"];
    $app->detail = $values["detail"];
    $app->start = $values["start"];
    $app->end = $values["end"];
    $app->isAllDay = $values["isAllDay"];
    $app->owners = $values["owners"];
    $app->shareStatusId = $values["shareStatusId"];
    $app->shareEmployees = $values["shareEmployees"];
    $app->modifiedDate = MamUtil::getCurrentDateTime();
    return $app;
}